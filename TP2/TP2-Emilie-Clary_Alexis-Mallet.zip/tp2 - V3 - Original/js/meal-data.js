let meal = [
    { idMeal:'0', name: 'Quesadillas', preparationTime: '30', ingredients: ['17','13','20','18'], preparationPrice: '3' },
    { idMeal:'1', name: 'Croque Monsieur Saumon Boursin', preparationTime: '15', ingredients: ['19','6','16'], preparationPrice: '2' },
    { idMeal:'2', name: 'Pates Carbonara - Françaises', preparationTime: '15', ingredients: ['0','3','4','5','22'], preparationPrice: '6' },
    { idMeal:'3', name: 'Pates Carbonara - Italiennes', preparationTime: '25', ingredients: ['0','1','2','22'], preparationPrice: '8' },
    { idMeal:'4', name: 'Salade composée', preparationTime: '5', ingredients: ['12','13','14','15'], preparationPrice: '1' },
    { idMeal:'5', name: 'Oeuf saumon en cocotte', preparationTime: '30', ingredients: ['5','6','4','7'], preparationPrice: '6' },
    { idMeal:'6', name: 'Pancakes', preparationTime: '14', ingredients: ['21','8','20','5','2'], preparationPrice: '5' },
    { idMeal:'7', name: 'Brownies', preparationTime: '45', ingredients: ['5','8','9','10','11','20'], preparationPrice: '8' },
];
